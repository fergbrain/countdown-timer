<?php
/*
Plugin Name: Countdown Timer
Plugin URI: http://www.andrewferguson.net/wordpress-plugins/
Plugin Description: Add template tages to coutn down the years, days, hours, minutes, and seconds to a particular event
Version: 0.7.1
Author: Andrew Ferguson
Author URI: http://www.andrewferguson.net
*/

/*Use: Enter each event you want to count down to on a seperate line in ./countdowntimer/dates.txt
	   The format is: MM-DD-YYYY HH:MM:SS Your Text Here
	   MM = (00-12); DD = (01-31); YYYY = (1970-2038); HH = (00-23); MM = (00-59); SS = (00-59)
/*
Countdown - Adds template tags to count down to a specified date

This code is licensed under the MIT License.
http://www.opensource.org/licenses/mit-license.php
Copyright (c) 2005 Andrew Ferguson

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to
do so, subject to the following conditions:

The above copyright notice and this permission notice shall
be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

function afdn_countdownTimer_myOptionsSubpanel(){

	
	if (isset($_POST['info_update']) && (!empty($_POST['dates'])))
	{
		$fh = fopen(dirname(__FILE__)."/cdt/dates.txt", "w+");
		$fw = fwrite($fh, $_POST['dates']);
		fclose($fh);
	}
	
	$file = implode('', file(dirname(__FILE__) . '/cdt/dates.txt'));
	?>
	
	<div class=wrap>
		<form method="post">
			<h2>Countdown Timer</h2>
			<p>
				   The format is:<br /> MM-DD-YYYY HH:MM:SS Your Text Here<br/><br />
				   MM = (00-12); DD = (01-31); YYYY = (1970-2038); HH = (00-23); MM = (00-59); SS = (00-59)
			
			
			</p>
			<fieldset name="set1">
				<legend><?php _e('dates.txt', 'Localization name') ?></legend>
				<textarea name="dates" cols="120" rows="10"><?php echo $file; ?></textarea>
			</fieldset>
			<div class="submit"><input type="submit" name="info_update" value="<?php
				_e('Update options', 'Localization name')
			 ?>&raquo;" /></div>
		</form>
	</div> <?
}



function afdn_countdownTimer_optionsPage(){
	if(function_exists('add_options_page')){
			add_options_page('Countdown Timer', 'Countdown Timer', 10, basename(__FILE__), 'afdn_countdownTimer_myOptionsSubpanel');
	}
}



function countdown_timer(){


	function cdt_format($text, $time, $offset){
		$time_left = $time - time() + $offset;
		if($time_left < 0){
			return NULL;
		}
		else{
		$content = "<li><b>".$text.":</b><br />\n";
		$content .= cdt_hms($time_left)."</li>";
		return $content;
		}
	}
	
	function cdt_hms($s, $min=1){
		$years=intval($s/31556736);
		$days=intval(($s-$years*31556736)/86400);
		$hours=intval(($s-($years*31556736)-($days*86400))/3600);
		$minutes=intval(($s-($years*31556736)-($days*86400)-($hours*3600))/60);
		$secs=$s%60;
		if ($years)
			$r=$r.$years.' years, ';
		if ($days)
			$r=$r.$days.' days, ';
		if ($hours)
			$r=$r.$hours.' hours, ';
		if($min)
			$r=$r.$minutes.' minutes';
		return $r;
	}
	
	//Read the file into an array
	$datefile = implode('', file(dirname(__FILE__) . '/cdt/dates.txt'));
	$dates = explode("\n", $datefile);
	$numDates = count($dates);
	//Split each event into Day, Time, and Text
	for($i = 0; $i < $numDates; $i++){
		$dates[$i] = explode(" ", $dates[$i], 3);
		$day = explode("-", $dates[$i][0]);
		$time = explode(":", $dates[$i][1]);
		echo cdt_format($dates[$i][2], mktime($time[0], $time[1], $time[2], $day[0], $day[1], $day[2]), (date("Z") - (get_settings('gmt_offset') * 3600)));
	}
}

add_action('admin_menu', 'afdn_countdownTimer_optionsPage');
?>