Tags: timer, countdown
Contributors:


HOW TO USE COUNTDOWN
====================

Upload the contents of cdt to your WordPress plugins directory (usually wp-content/plugins).

In the WordPress admin console, go to the Plugins tab, and activate the Countdown Timer plugin.

Put this code into your sidebar menu:

<li id="countdown"><h2>Countdown:</h2>
    <ul>
    <?php
    countdown_timer();
    ?>
    </ul>
</li>


ADDING NEW EVENTS
-----------------

The formatting for the dates in the dates.txt file is pretty self-explanatory and uses the following format:

MM-DD-YYYY HH:MM:SS Your Text Here


MM is the month, always expressed using a two digit value between 00-12
DD is the day, always expressed using a two digit value between 01-31
YYYY is the year, always expressed using a four digit value between 1970-2038
HH is the hour, always expressed using a two digit value between 00-23 (i.e. military time)
MM is the minutes, always expressed using a two digit value between 00-59
SS is the seconds, always expressed using a two digit value between 00-59



