Tags: timer, countdown
Contributors:


HOW TO USE COUNTDOWN
====================

Upload the contents of cdt to your WordPress plugins directory (usually wp-content/plugins).

In the WordPress admin console, go to the Plugins tab, and activate the Countdown Timer plugin.

Put this code into your sidebar menu:

<li id="countdown"><h2>Countdown:</h2>
    <ul>
    <?php
    countdown_timer();
    ?>
    </ul>
</li>

Go to Options > Countdown Timer to add new events


MANAGING EVENTS
-----------------

The left hand input field is for the dates. It uses PHP's strtodate (string to date) function to generate a unix timestamp. From PHP.net:

The function expects to be given a string containing a US English date format and will try to parse that format into a Unix timestamp (the number of seconds since January 1 1970 00:00:00 GMT), relative to the timestamp given in now, or the current time if none is supplied.

The right hand describes what the event is.

After adding a new event, the list is ordered from occuring soonest to occuring latest and then added to the WordPress Database.

Once an event has occured, it is no longer displayed on the home page. Although it is still shown on the Countdown Timer Panel in the admin section.